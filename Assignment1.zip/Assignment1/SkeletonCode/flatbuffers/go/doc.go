// Package flatbuffers provides facilities to read and write flatbuffers
// objects.
package flatbuffers
