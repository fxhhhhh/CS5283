export default {
  input: 'mjs/index.js',
  output: {
    file: 'flatbuffers.js',
    format: 'iife',
    name: 'flatbuffers'
  }
}