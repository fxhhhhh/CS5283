export enum Encoding {
    UTF8_BYTES = 1,
    UTF16_STRING = 2
}